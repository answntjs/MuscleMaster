package user;

/**
 * 플레이어(캐릭터)의 현재 RPG 상태를 나타내는 열거형.
 *
 * <p>[설계 의도 / 구현 지침]
 * <ul>
 *   <li>{@link #NORMAL}: 기본 상태 (경험치 배율 1.0)</li>
 *   <li>{@link #ON_FIRE}: 연속 운동(streakDays) 조건 충족 시 활성화되는 버프 상태 (예: 3일 이상 연속)</li>
 *   <li>{@link #PENALTY}: 루틴/퀘스트 실패 시 부여되는 패널티 상태 (예: 획득 경험치 감소, 다음 퀘스트 완료 시 회복)</li>
 * </ul>
 */
public enum CharacterStatus {
    NORMAL("보통", 1.0),
    ON_FIRE("열정", 1.15),
    PENALTY("슬럼프", 0.8);

    private final String label;
    private final double expMultiplier;

    CharacterStatus(String label, double expMultiplier) {
        this.label = label;
        this.expMultiplier = expMultiplier;
    }

    public String getLabel() {
        return label;
    }

    /**
     * 상태에 따른 경험치 보정 배율을 반환한다.
     *
     * @return 경험치 배율 (예: 1.0, 1.15, 0.8)
     */
    public double getExpMultiplier() {
        return expMultiplier;
    }
}
