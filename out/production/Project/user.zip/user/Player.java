package user;

import common.Muscle;
import quest.Quest;
import routine.RoutineManager;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 유저(=플레이어=RPG 캐릭터)를 표현하는 핵심 도메인 클래스.
 *
 * <p>[설계 개요 및 책임]
 * <ol>
 *   <li><b>캐릭터 상태 캡슐화</b>: 이름, 캐릭터 레벨({@code level}), 현재 경험치({@code exp}),
 *       연속 기록 일수({@code streakDays}), 마지막 활동일({@code lastActiveDate}), 상태({@link CharacterStatus}) 관리</li>
 *   <li><b>부위별 성장 매핑</b>: {@link Muscle#BODYPARTS} 기준으로 각 부위의 {@link BodyPartProgress}를 관리하며,
 *       복합 운동 퀘스트의 근육 구성 비율에 따라 경험치를 분배</li>
 *   <li><b>루틴 및 퀘스트 소유</b>: {@link RoutineManager}와 진행 중인 퀘스트({@code activeQuests}),
 *       완료된 퀘스트({@code completedQuests})를 직접 소유하고 생명주기를 관리</li>
 *   <li><b>성장 및 패널티</b>: 퀘스트/루틴 완료 시 {@code streakDays} 보정을 포함한 레벨업,
 *       실패 시 경험치 차감(단, 레벨 차감 없음) 및 패널티 상태 적용</li>
 * </ol>
 *
 * <p>[불변식 (Invariants)]
 * <ul>
 *   <li>{@code name}은 null이거나 공백일 수 없다.</li>
 *   <li>{@code level >= 1}, {@code exp >= 0}, {@code streakDays >= 0}</li>
 *   <li>경험치 차감 시에도 {@code level}은 절대 감소하지 않으며, {@code exp}의 최솟값은 {@code 0}이다.</li>
 *   <li>{@code activeQuests}와 {@code completedQuests}에 동일한 {@link Quest} 인스턴스가 중복 존재할 수 없다.</li>
 *   <li>외부 getter로 반환하는 컬렉션은 수정 불가 뷰({@code Collections.unmodifiable...})여야 한다.</li>
 * </ul>
 *
 * <p>[AI / 개발자 구현 가이드]
 * <ul>
 *   <li>각 메서드의 {@code TODO} 주석과 Javadoc 명세를 기준으로 구현하세요.</li>
 *   <li>{@code level}, {@code exp}, {@code streakDays}에 대한 public setter를 추가하지 마세요.</li>
 *   <li>날짜 기준 판단은 {@link LocalDate#now()}를 하드코딩하지 말고 메서드 인자로 전달받은 {@code date}를 사용하세요(테스트 용이성).</li>
 * </ul>
 */
public class Player {
    public static final int CHAR_BASE_REQUIRED_EXP = 100;
    public static final int CHAR_LINEAR_EXP_STEP = 50;
    public static final int CHAR_QUADRATIC_EXP_STEP = 10;

    public static final double MAX_STREAK_BONUS = 0.50;          // 연속 운동 보너스 최대 +50%
    public static final double STREAK_LOG_COEFFICIENT = 0.10;    // 자연로그 성장 계수
    public static final int ON_FIRE_STREAK_THRESHOLD = 3;        // 3일 연속 달성 시 ON_FIRE 상태
    public static final double DEFAULT_FAILURE_PENALTY_RATE = 0.5; // 실패 시 퀘스트 EXP의 50% 차감

    private final String name;
    private int level;
    private int exp;
    private int streakDays;
    private LocalDate lastActiveDate;
    private CharacterStatus status;

    private final Map<String, BodyPartProgress> partProgressMap;
    private final RoutineManager routineManager;
    private final List<Quest> activeQuests;
    private final List<Quest> completedQuests;

    public Player(String name) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("플레이어 이름은 비어 있을 수 없습니다.");
        }
        this.name = name.trim();
        this.level = 1;
        this.exp = 0;
        this.streakDays = 0;
        this.lastActiveDate = null;
        this.status = CharacterStatus.NORMAL;

        this.partProgressMap = new LinkedHashMap<>();
        for (String bodyPart : Muscle.BODYPARTS) {
            this.partProgressMap.put(bodyPart, new BodyPartProgress(bodyPart));
        }

        this.routineManager = new RoutineManager();
        this.activeQuests = new ArrayList<>();
        this.completedQuests = new ArrayList<>();
    }

    // ==================== 조회용 Getter (캡슐화 유지) ====================

    public String getName() {
        return name;
    }

    public int getLevel() {
        return level;
    }

    public int getExp() {
        return exp;
    }

    public int getStreakDays() {
        return streakDays;
    }

    public LocalDate getLastActiveDate() {
        return lastActiveDate;
    }

    public CharacterStatus getStatus() {
        return status;
    }

    public RoutineManager getRoutineManager() {
        return routineManager;
    }

    public Map<String, BodyPartProgress> getPartProgressMap() {
        return Collections.unmodifiableMap(partProgressMap);
    }

    public BodyPartProgress getPartProgress(String bodyPart) {
        return partProgressMap.get(bodyPart);
    }

    public List<Quest> getActiveQuests() {
        return Collections.unmodifiableList(activeQuests);
    }

    public List<Quest> getCompletedQuests() {
        return Collections.unmodifiableList(completedQuests);
    }

    // ==================== 경험치 및 보정 수식 ====================

    /**
     * 현재 캐릭터 레벨({@code level})에서 다음 레벨로 올라가기 위한 요구 경험치를 반환한다.
     *
     * <p>[권장 수식 — 초반 습관 형성(Newbie Gains) + 점진적 난이도 상승]
     * <pre>
     * requiredCharacterExp(L) = 100 + 50 * (L - 1) + 10 * (L - 1)^2
     * </pre>
     * <ul>
     *   <li>초반 레벨(Lv.1~3)은 빠르게 올라 동기부여를 주고, 고레벨로 갈수록 꾸준한 운동량을 요구하되 지수 폭발은 방지한다.</li>
     *   <li>예시: Lv.1→100, Lv.2→160, Lv.3→240, Lv.5→460, Lv.10→1360</li>
     * </ul>
     *
     * @return 다음 캐릭터 레벨업에 필요한 경험치
     */
    public int getRequiredExp() {
        // TODO: 캐릭터 레벨업 요구 경험치 수식을 구현하세요.
        throw new UnsupportedOperationException("TODO: Player.getRequiredExp() 구현 필요");
    }

    /**
     * 연속 운동 일수({@code streakDays})에 따른 경험치 보정 배율을 반환한다.
     *
     * <p>[권장 수식 — 운동의 꾸준함 &amp; 점근선(Diminishing Returns) 모델]
     * <pre>
     * streakMultiplier(days) = 1.0 + min(0.50, 0.10 * ln(max(1, days)))
     * </pre>
     * <ul>
     *   <li>운동 초기(1~21일 습관 형성기)에는 연속 보너스가 빠르게 체감된다:
     *       1일=1.00배, 3일≈1.11배, 7일≈1.19배, 14일≈1.26배, 21일≈1.30배, 30일≈1.34배</li>
     *   <li>장기적으로는 최대 1.50배(+50%) 상한에 수렴하여 밸런스 붕괴를 막는다.</li>
     * </ul>
     *
     * @return 1.0 이상 1.5 이하의 연속 보너스 배율
     */
    public double getStreakMultiplier() {
        // TODO: streakDays 기반 경험치 보정 수식을 구현하세요.
        throw new UnsupportedOperationException("TODO: Player.getStreakMultiplier() 구현 필요");
    }

    // ==================== 루틴 연동 및 퀘스트 진행 ====================

    /**
     * 특정 날짜에 해당하는 루틴 퀘스트들을 {@link RoutineManager}로부터 발급받아 {@code activeQuests}에 등록한다.
     *
     * <p>[구현 지침]
     * <ol>
     *   <li>{@code date == null}이면 {@link IllegalArgumentException}을 던진다.</li>
     *   <li>{@code List<Quest> granted = routineManager.grantQuestsForDate(date);} 호출</li>
     *   <li>발급된 퀘스트들을 {@code activeQuests}에 추가하고 반환한다.</li>
     * </ol>
     *
     * @param date 퀘스트를 발급할 기준 날짜
     * @return 이번 호출로 새롭게 {@code activeQuests}에 추가된 퀘스트 목록
     */
    public List<Quest> assignQuestsForDate(LocalDate date) {
        // TODO: RoutineManager.grantQuestsForDate(date) 결과를 activeQuests에 추가하고 반환하세요.
        throw new UnsupportedOperationException("TODO: Player.assignQuestsForDate(LocalDate) 구현 필요");
    }

    /**
     * 진행 중인 퀘스트의 세트를 수행하고, 목표 세트 달성 시 완료 처리 및 경험치 정산까지 이어간다.
     *
     * <p>[구현 지침]
     * <ol>
     *   <li>{@code quest}가 {@code null}이거나 {@code activeQuests}에 없으면 예외 처리(또는 false 반환)한다.</li>
     *   <li>{@code sets <= 0}이면 {@link IllegalArgumentException}을 던진다.</li>
     *   <li>{@code quest.doSet(sets)}를 호출해 세트 수를 증가시킨다.</li>
     *   <li>{@code quest.isCompleted()}가 {@code true}가 되면 {@link #completeQuest(Quest, LocalDate)}를 호출해 보상을 정산한다.</li>
     * </ol>
     *
     * @param quest 진행할 퀘스트 ({@code activeQuests}에 포함되어 있어야 함)
     * @param sets  수행한 세트 수 (1 이상)
     * @param date  수행 날짜
     * @return 이번 호출로 퀘스트가 최종 완료되었으면 {@code true}, 아직 진행 중이면 {@code false}
     */
    public boolean progressQuest(Quest quest, int sets, LocalDate date) {
        // TODO: activeQuests 포함 여부 확인 -> quest.doSet(sets) -> 완료 시 completeQuest 호출
        throw new UnsupportedOperationException("TODO: Player.progressQuest(Quest, int, LocalDate) 구현 필요");
    }

    /**
     * 완료된 퀘스트를 {@code activeQuests}에서 {@code completedQuests}로 이동하고,
     * 연속 일수 갱신, 캐릭터 레벨업, 부위별 비율 경험치 반영을 수행한다.
     *
     * <p>[구현 지침]
     * <ol>
     *   <li>{@code quest}와 {@code date}의 null 검사 및 {@code activeQuests.contains(quest)} 확인</li>
     *   <li>{@code !quest.isCompleted()}이면 {@link IllegalStateException} (또는 {@link IllegalArgumentException}) 발생</li>
     *   <li>{@code activeQuests.remove(quest)} 및 {@code completedQuests.add(quest)}로 중복 정산 방지</li>
     *   <li>{@link #updateStreak(LocalDate)}로 {@code streakDays}, {@code lastActiveDate}, {@code status} 갱신</li>
     *   <li>최종 획득 경험치 계산:
     *       {@code int finalExp = (int) Math.round(quest.getExp() * getStreakMultiplier() * status.getExpMultiplier());}
     *       (단, 기존 {@code PENALTY} 상태였다면 완료 시 {@code NORMAL}로 회복할지, 이번 정산까지 패널티를 적용한 뒤 회복할지 순서 명시)</li>
     *   <li>{@link #gainCharacterExp(int)}로 캐릭터 EXP 가산 및 레벨업</li>
     *   <li>{@link #distributePartExp(Quest, int)}로 부위별 비율 경험치 분배 및 부위 레벨업</li>
     * </ol>
     *
     * @param quest 완료 처리할 퀘스트
     * @param date  완료 날짜
     */
    public void completeQuest(Quest quest, LocalDate date) {
        // TODO: 퀘스트 완료 상태 전환, streak 갱신, 보정 EXP 계산, 캐릭터/부위 경험치 정산을 구현하세요.
        throw new UnsupportedOperationException("TODO: Player.completeQuest(Quest, LocalDate) 구현 필요");
    }

    // ==================== 실패 및 패널티 처리 ====================

    /**
     * 진행 중인 특정 퀘스트를 실패 처리하고 캐릭터 경험치를 차감한다.
     *
     * <p>[구현 지침]
     * <ol>
     *   <li>{@code quest}가 {@code activeQuests}에 존재하는지 확인한다.</li>
     *   <li>{@code activeQuests.remove(quest)}로 진행 중 목록에서 제거한다.</li>
     *   <li>패널티 경험치 계산: 예) {@code (int) Math.round(quest.getExp() * DEFAULT_FAILURE_PENALTY_RATE)}</li>
     *   <li>{@link #penalizeCharacterExp(int)}를 호출해 경험치를 차감한다. (<b>레벨 차감 금지</b>)</li>
     *   <li>{@code streakDays = 0} 으로 초기화하고 {@code status = CharacterStatus.PENALTY} 로 전환한다.</li>
     * </ol>
     *
     * @param quest 실패 처리할 진행 중 퀘스트
     */
    public void failQuest(Quest quest) {
        // TODO: 단일 퀘스트 실패 처리, EXP 차감(레벨 유지), streak 초기화, PENALTY 상태 전환을 구현하세요.
        throw new UnsupportedOperationException("TODO: Player.failQuest(Quest) 구현 필요");
    }

    /**
     * 현재 {@code activeQuests}에 남아있는 미완료 퀘스트 전체를 일괄 실패 처리한다.
     * (예: 하루가 마감되었을 때 수행하지 못한 루틴 정산용)
     *
     * <p>[구현 지침]
     * <ul>
     *   <li>{@code activeQuests}가 비어 있으면 아무 작업도 하지 않는다.</li>
     *   <li>리스트 순회 중 수정(ConcurrentModificationException)을 피하기 위해 복사본을 순회하거나 {@link #failQuest(Quest)}를 활용한다.</li>
     * </ul>
     */
    public void failAllActiveQuests() {
        // TODO: 남은 activeQuests 일괄 실패 정산 로직을 구현하세요.
        throw new UnsupportedOperationException("TODO: Player.failAllActiveQuests() 구현 필요");
    }

    // ==================== 내부 헬퍼 메서드 명세 (protected / private) ====================

    /**
     * 마지막 활동일({@code lastActiveDate})과 {@code date}를 비교해 연속 일수({@code streakDays}) 및 상태를 갱신한다.
     *
     * <p>[구현 지침]
     * <ul>
     *   <li>{@code lastActiveDate == null}: 첫 운동 → {@code streakDays = 1}</li>
     *   <li>{@code date.equals(lastActiveDate)}: 같은 날 추가 완료 → {@code streakDays} 유지</li>
     *   <li>{@code date.equals(lastActiveDate.plusDays(1))}: 어제에 이어 연속 완료 → {@code streakDays++}</li>
     *   <li>{@code date.isAfter(lastActiveDate.plusDays(1))}: 하루 이상 공백 → {@code streakDays = 1}로 재시작</li>
     *   <li>{@code date.isBefore(lastActiveDate)}: 과거 날짜 입력 → {@link IllegalArgumentException} 또는 무시</li>
     *   <li>{@code lastActiveDate = date} 갱신 후, {@code streakDays >= ON_FIRE_STREAK_THRESHOLD}면 {@code status = CharacterStatus.ON_FIRE},
     *       아니면 {@code status = CharacterStatus.NORMAL}로 회복한다.</li>
     * </ul>
     */
    protected void updateStreak(LocalDate date) {
        // TODO: 날짜 비교 기반 streakDays 및 status 갱신 로직을 구현하세요.
        throw new UnsupportedOperationException("TODO: Player.updateStreak(LocalDate) 구현 필요");
    }

    /**
     * 퀘스트에 포함된 근육({@link Quest#getMuscles()})을 {@link Muscle#MUSCLE_TO_BODY}로 매핑하여
     * 각 신체 부위가 차지하는 비율을 계산한다.
     *
     * <p>[동작 예시]
     * <ul>
     *   <li>근육이 {@code ["광배근", "삼각근", "회전근개"]}인 경우:
     *       {@code "등"} 1개, {@code "어깨"} 2개 → 총 3개 → {@code {"등": 1/3, "어깨": 2/3}}</li>
     *   <li>만약 {@code getMuscles()}에서 매핑되는 부위가 하나도 없고 {@link Quest#getParts()}가 비어 있지 않다면,
     *       {@code getParts()}에 포함된 부위에 균등 비율({@code 1.0 / parts.size()})을 부여한다.</li>
     * </ul>
     *
     * @param quest 비율을 계산할 퀘스트
     * @return 부위명 -> 비율(0.0 ~ 1.0, 합계 1.0) 맵
     */
    protected Map<String, Double> calculatePartRatios(Quest quest) {
        // TODO: Muscle.MUSCLE_TO_BODY를 이용해 부위별 등장 횟수를 집계하고 비율 Map을 생성하세요.
        throw new UnsupportedOperationException("TODO: Player.calculatePartRatios(Quest) 구현 필요");
    }

    /**
     * {@link #calculatePartRatios(Quest)}로 구한 비율을 반영해 각 부위({@link BodyPartProgress})에 경험치를 분배한다.
     *
     * <p>[구현 지침]
     * <ul>
     *   <li>각 부위별 획득 경험치: {@code int partExp = (int) Math.round(totalGainedExp * ratio);}</li>
     *   <li>{@code totalGainedExp > 0}이고 {@code ratio > 0}인데 반올림 결과가 0이면 최소 1 EXP를 부여할지 정책을 일관되게 유지한다.</li>
     *   <li>{@code partProgressMap.get(part)}가 존재하면 {@link BodyPartProgress#gainExp(int)}를 호출한다.</li>
     * </ul>
     */
    protected void distributePartExp(Quest quest, int totalGainedExp) {
        // TODO: 부위별 비율에 따라 BodyPartProgress.gainExp를 호출하세요.
        throw new UnsupportedOperationException("TODO: Player.distributePartExp(Quest, int) 구현 필요");
    }

    /**
     * 캐릭터 경험치를 가산하고 다중 레벨업을 처리한다.
     *
     * <p>[구현 지침]
     * <ol>
     *   <li>{@code amount < 0}이면 {@link IllegalArgumentException}</li>
     *   <li>{@code this.exp += amount;}</li>
     *   <li>{@code while (this.exp >= getRequiredExp()) { this.exp -= getRequiredExp(); this.level++; }}</li>
     * </ol>
     */
    protected void gainCharacterExp(int amount) {
        // TODO: 캐릭터 EXP 가산 및 while 루프 레벨업 구현
        throw new UnsupportedOperationException("TODO: Player.gainCharacterExp(int) 구현 필요");
    }

    /**
     * 캐릭터 경험치를 차감한다. <b>레벨 차감은 절대 발생하지 않는다.</b>
     *
     * <p>[구현 지침]
     * <ol>
     *   <li>{@code amount < 0}이면 {@link IllegalArgumentException}</li>
     *   <li>{@code this.exp = Math.max(0, this.exp - amount);} (하한 0, {@code this.level} 유지)</li>
     * </ol>
     */
    protected void penalizeCharacterExp(int amount) {
        // TODO: 레벨 차감 없이 exp를 최소 0까지 차감하도록 구현
        throw new UnsupportedOperationException("TODO: Player.penalizeCharacterExp(int) 구현 필요");
    }

    @Override
    public String toString() {
        return String.format("%s [Lv.%d | EXP %d | 연속 %d일 | 상태: %s | 진행중 %d개 / 완료 %d개]",
                name, level, exp, streakDays, status.getLabel(), activeQuests.size(), completedQuests.size());
    }
}
