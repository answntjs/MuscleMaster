package user;

/**
 * 특정 신체 부위({@code common.Muscle.BODYPARTS})의 성장 상태(부위 레벨, 현재 경험치, 누적 경험치)를 캡슐화하는 클래스.
 *
 * <p>[불변식 (Invariants)]
 * <ul>
 *   <li>{@code partName}은 null이거나 비어 있을 수 없다.</li>
 *   <li>{@code level >= 1}</li>
 *   <li>{@code exp >= 0} 이며, 항상 {@code exp < getRequiredExp()} 상태를 유지해야 한다.</li>
 *   <li>{@code totalExp >= 0} 이며, 지금까지 해당 부위가 획득한 순수 누적 경험치를 보존한다.</li>
 *   <li>패널티(실패)로 인해 부위 레벨이나 부위 경험치가 차감되지 않는다.</li>
 * </ul>
 *
 * <p>[AI / 개발자 구현 가이드]
 * <ul>
 *   <li>모든 상태 변경은 {@link #gainExp(int)}를 통해서만 수행한다.</li>
 *   <li>외부에서 레벨이나 경험치를 직접 덮어쓰는 setter는 제공하지 않는다.</li>
 * </ul>
 */
public class BodyPartProgress {
    public static final int BASE_REQUIRED_EXP = 50;
    public static final int LINEAR_EXP_STEP = 30;
    public static final int QUADRATIC_EXP_STEP = 5;

    private final String partName;
    private int level;
    private int exp;
    private int totalExp;

    public BodyPartProgress(String partName) {
        if (partName == null || partName.isBlank()) {
            throw new IllegalArgumentException("부위명은 비어 있을 수 없습니다.");
        }
        this.partName = partName;
        this.level = 1;
        this.exp = 0;
        this.totalExp = 0;
    }

    public String getPartName() {
        return partName;
    }

    public int getLevel() {
        return level;
    }

    public int getExp() {
        return exp;
    }

    public int getTotalExp() {
        return totalExp;
    }

    /**
     * 현재 부위 레벨({@code level})에서 다음 레벨로 올라가기 위해 필요한 경험치를 반환한다.
     *
     * <p>[권장 수식 — 운동 근성장 곡선 반영]
     * <pre>
     * requiredPartExp(L) = 50 + 30 * (L - 1) + 5 * (L - 1)^2
     * </pre>
     * <ul>
     *   <li>단일 부위는 전체 퀘스트 경험치를 부위 비율만큼 나누어 받으므로 캐릭터 레벨보다 요구량을 작게 설정한다.</li>
     *   <li>예시: Lv.1→50, Lv.2→85, Lv.3→130, Lv.5→250</li>
     * </ul>
     *
     * @return 다음 부위 레벨업에 필요한 경험치 (항상 1 이상)
     */
    public int getRequiredExp() {
        // TODO: 위 수식(또는 팀에서 합의한 부위별 요구 경험치 수식)을 구현하세요.
        throw new UnsupportedOperationException("TODO: BodyPartProgress.getRequiredExp() 구현 필요");
    }

    /**
     * 해당 부위에 경험치를 가산하고, 필요 경험치를 넘기면 부위 레벨업을 처리한다.
     *
     * <p>[구현 지침]
     * <ol>
     *   <li>{@code amount < 0}이면 {@link IllegalArgumentException}을 던진다. (0이면 아무 작업 없이 종료)</li>
     *   <li>{@code this.totalExp += amount} 로 누적 경험치를 기록한다.</li>
     *   <li>{@code this.exp += amount} 로 현재 레벨 경험치를 가산한다.</li>
     *   <li>한 번에 다량의 경험치를 얻어 다중 레벨업할 수 있으므로 {@code while (this.exp >= getRequiredExp())} 루프로
     *       {@code this.exp -= getRequiredExp(); this.level++;} 를 반복 처리한다.</li>
     * </ol>
     *
     * @param amount 획득한 부위 경험치 (0 이상)
     */
    public void gainExp(int amount) {
        // TODO: 유효성 검증, totalExp 누적, while 루프 기반 다중 레벨업 로직을 구현하세요.
        throw new UnsupportedOperationException("TODO: BodyPartProgress.gainExp(int) 구현 필요");
    }

    @Override
    public String toString() {
        return String.format("%s Lv.%d (EXP %d / 누적 %d)", partName, level, exp, totalExp);
    }
}
